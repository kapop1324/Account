package com.ryu.account.model.service;

import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ryu.account.model.Uservo;
import com.ryu.account.model.dao.UserDao;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	private SqlSession sqlsession;
	
	@Override
	public boolean signup(Map map) throws Exception{
		
		return sqlsession.getMapper(UserDao.class).signup(map);
	}

	@Override
	public Uservo signin(Map map) throws Exception{
		
		return sqlsession.getMapper(UserDao.class).signin(map);
	}

}
