package com.ryu.account.model.service;

import java.util.ArrayList;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ryu.account.model.AccountSpendvo;
import com.ryu.account.model.Accountvo;
import com.ryu.account.model.CardSpendvo;
import com.ryu.account.model.Cardvo;
import com.ryu.account.model.Datavo;
import com.ryu.account.model.Incomevo;
import com.ryu.account.model.SpendtypeCountvo;
import com.ryu.account.model.Stockvo;
import com.ryu.account.model.dao.AccountDao;

@Service
public class AccountServiceImpl implements AccountService {
	
	@Autowired
	SqlSession sqlsession;

	@Override
	public boolean register(Map map) throws Exception {
		
		return sqlsession.getMapper(AccountDao.class).register(map);
	}

	@Override
	public ArrayList<Accountvo> get_account() throws Exception {
		
		return sqlsession.getMapper(AccountDao.class).get_account();
	}


	@Override
	public boolean account_spend_register(Map map) throws Exception {
		
		return sqlsession.getMapper(AccountDao.class).account_spend_register(map);
	}

	@Override
	public ArrayList<AccountSpendvo> get_accountspend( ) throws Exception {
		
		return sqlsession.getMapper(AccountDao.class).get_accountspend();
	}
	
	@Override
	public ArrayList<AccountSpendvo> get_accountspend2(Map map ) throws Exception {
		
		return sqlsession.getMapper(AccountDao.class).get_accountspend2(map);
	}

	@Override
	public boolean income_register(Map map) throws Exception {
		
		return sqlsession.getMapper(AccountDao.class).income_register(map);
	}

	
	//rest

	@Override
	public ArrayList<CardSpendvo> yearlyspend() throws Exception {
		
		return sqlsession.getMapper(AccountDao.class).yearlyspend();
	}

	@Override
	public ArrayList<AccountSpendvo> yearlyaccountspend( ) throws Exception {
		
		return sqlsession.getMapper(AccountDao.class).yearlyaccountspend();
	}

	@Override
	public ArrayList<SpendtypeCountvo> yearlyspendtype() throws Exception {
		
		return sqlsession.getMapper(AccountDao.class).yearlyspendtype();
	}

	@Override
	public ArrayList<Incomevo> yearlyincome( ) throws Exception {

		return sqlsession.getMapper(AccountDao.class).yearlyincome();
	}
	
	@Override
	public ArrayList<Incomevo> yearlyincomegroup( ) throws Exception {

		return sqlsession.getMapper(AccountDao.class).yearlyincomegroup();
	}
	
	@Override
	public ArrayList<Incomevo> yearlyincomemonth( ) throws Exception {

		return sqlsession.getMapper(AccountDao.class).yearlyincomemonth();
	}

	@Override
	public ArrayList<Datavo> yearlydelivery( ) throws Exception {

		return sqlsession.getMapper(AccountDao.class).yearlydelivery();
	}

	@Override
	public ArrayList<Datavo> yearlygrocery( ) throws Exception {

		return sqlsession.getMapper(AccountDao.class).yearlygrocery();
	}

	@Override
	public ArrayList<Datavo> yearlyrest( ) throws Exception {
		
		return sqlsession.getMapper(AccountDao.class).yearlyrest();
	}

	@Override
	public Stockvo stock() throws Exception {
		
		return sqlsession.getMapper(AccountDao.class).stock();
	}

	@Override
	public SpendtypeCountvo navercookie() throws Exception {
		
		return sqlsession.getMapper(AccountDao.class).navercookie();
	}

	@Override
	public ArrayList<Accountvo> get_stock() throws Exception {
		
		return sqlsession.getMapper(AccountDao.class).get_stock();
	}

	@Override
	public boolean stockregister(Map map) throws Exception {
		
		return sqlsession.getMapper(AccountDao.class).stockregister(map);
	}

	@Override
	public ArrayList<Incomevo> yearlyincome2(Map map) throws Exception {
		
		return sqlsession.getMapper(AccountDao.class).yearlyincome2(map);
	}

	@Override
	public int incomecount() throws Exception {
		
		return sqlsession.getMapper(AccountDao.class).incomecount();
	}

	@Override
	public int spendcount() throws Exception {
		
		return sqlsession.getMapper(AccountDao.class).spendcount();
	}

	@Override
	public boolean spend_update(Map map) throws Exception {
		
		return sqlsession.getMapper(AccountDao.class).spend_update(map);
	}

	@Override
	public boolean income_update(Map map) throws Exception {
		
		return sqlsession.getMapper(AccountDao.class).income_update(map);
	}
	
	@Override
	public boolean stock_update(Map map) throws Exception {
		
		return sqlsession.getMapper(AccountDao.class).stock_update(map);
	}
	
	@Override
	public boolean stock_update2(Map map) throws Exception {
		
		return sqlsession.getMapper(AccountDao.class).stock_update2(map);
	}
	
	@Override
	public boolean stock_update3(Map map) throws Exception {
		
		return sqlsession.getMapper(AccountDao.class).stock_update3(map);
	}

	

}
