package com.ryu.account.model.dao;

import java.sql.SQLException;
import java.util.Map;

import com.ryu.account.model.Uservo;

public interface UserDao {
	
	public Uservo signin(Map map) throws Exception;
	public boolean signup(Map map) throws Exception;

}
