package com.ryu.account.model.dao;

import java.util.ArrayList;
import java.util.Map;

import com.ryu.account.model.AccountSpendvo;
import com.ryu.account.model.Accountvo;
import com.ryu.account.model.CardSpendvo;
import com.ryu.account.model.Cardvo;
import com.ryu.account.model.Datavo;
import com.ryu.account.model.Incomevo;
import com.ryu.account.model.SpendtypeCountvo;
import com.ryu.account.model.Stockvo;

public interface AccountDao {
	
	public boolean register(Map map) throws Exception;
	
	public boolean stockregister(Map map) throws Exception;
	
	public ArrayList<Accountvo> get_account( ) throws Exception;
	
	public ArrayList<Accountvo> get_stock( ) throws Exception;
	
	public boolean account_spend_register(Map map) throws Exception;
	
	public ArrayList<AccountSpendvo> get_accountspend() throws Exception;
	public ArrayList<AccountSpendvo> get_accountspend2(Map map) throws Exception;
	
	public boolean income_register(Map map) throws Exception;
	
	public Stockvo stock() throws Exception;
	
	public SpendtypeCountvo navercookie() throws Exception;
	
	public int incomecount() throws Exception;
	
	public int spendcount() throws Exception;
	
	public boolean spend_update(Map map) throws Exception;
	
	public boolean stock_update(Map map) throws Exception;
	
	public boolean stock_update2(Map map) throws Exception;
	public boolean stock_update3(Map map) throws Exception;
	
	public boolean income_update(Map map) throws Exception;
	
	//rest
	
	public ArrayList<CardSpendvo> yearlyspend() throws Exception;
	
	public ArrayList<AccountSpendvo> yearlyaccountspend() throws Exception;
	
	public ArrayList<SpendtypeCountvo> yearlyspendtype( ) throws Exception;
	
	public ArrayList<Incomevo> yearlyincome( ) throws Exception;
	public ArrayList<Incomevo> yearlyincome2(Map map ) throws Exception;
	public ArrayList<Incomevo> yearlyincomegroup( ) throws Exception;
	
	public ArrayList<Incomevo> yearlyincomemonth( ) throws Exception;
	
	public ArrayList<Datavo> yearlydelivery( ) throws Exception;
	
	public ArrayList<Datavo> yearlygrocery( ) throws Exception;
	
	public ArrayList<Datavo> yearlyrest( ) throws Exception;

}
