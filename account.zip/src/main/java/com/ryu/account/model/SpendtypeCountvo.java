package com.ryu.account.model;

public class SpendtypeCountvo {
	
	private String spend_type;
	private int count;
	private int money;
	public int getMoney() {
		return money;
	}
	public void setMoney(int money) {
		this.money = money;
	}
	public String getSpend_type() {
		return spend_type;
	}
	public void setSpend_type(String spend_type) {
		this.spend_type = spend_type;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}

}
