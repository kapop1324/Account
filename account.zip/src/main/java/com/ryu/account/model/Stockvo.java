package com.ryu.account.model;

public class Stockvo {
	private int invest;
	private int now;
	private int per;
	public int getInvest() {
		return invest;
	}
	public void setInvest(int invest) {
		this.invest = invest;
	}
	public int getNow() {
		return now;
	}
	public void setNow(int now) {
		this.now = now;
	}
	public int getPer() {
		return per;
	}
	public void setPer(int per) {
		this.per = per;
	}

}
