package com.ryu.account.model.service;

import java.util.Map;

import com.ryu.account.model.Uservo;

public interface UserService {
	
	public Uservo signin(Map map) throws Exception;
	public boolean signup(Map map) throws Exception;

}
