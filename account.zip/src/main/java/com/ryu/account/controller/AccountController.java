package com.ryu.account.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ryu.account.model.AccountSpendvo;
import com.ryu.account.model.Accountvo;
import com.ryu.account.model.CardSpendvo;
import com.ryu.account.model.Cardvo;
import com.ryu.account.model.Datavo;
import com.ryu.account.model.Incomevo;
import com.ryu.account.model.SpendtypeCountvo;
import com.ryu.account.model.Stockvo;
import com.ryu.account.model.Uservo;
import com.ryu.account.model.service.AccountService;

@Controller
@RequestMapping("/account")
public class AccountController {
	
	@Autowired
	AccountService accountservice;
	
	@GetMapping("/yearly")
	public String yearly(HttpServletRequest request) {
		
		try {
			List<Incomevo> yearly_income = accountservice.yearlyincomegroup();
			request.setAttribute("yearly_income", yearly_income);
			
			List<SpendtypeCountvo> yearly_spend_type = accountservice.yearlyspendtype();
			request.setAttribute("yearly_spend_type", yearly_spend_type);
			
			Stockvo stock = accountservice.stock();
			request.setAttribute("stock", stock);
			
			SpendtypeCountvo navercookie = accountservice.navercookie();
			request.setAttribute("navercookie", navercookie);
			
			List<Datavo> yearly_delivery = accountservice.yearlydelivery();
			request.setAttribute("yearly_delivery", yearly_delivery);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		return "yearly";
	}
	
	
	
	@GetMapping("/account")
	public String account(HttpServletRequest request,Model model,@RequestParam Map map) {
		
		try {
			
			
			ArrayList<Accountvo> account_list = accountservice.get_account();
			request.setAttribute("account_list", account_list);
			
			ArrayList<Accountvo> stock_list = accountservice.get_stock();
			request.setAttribute("stock_list", stock_list);
			
			String spendnum1 = (String) map.get("spendnum");
			int spendnum = 1;
			if(spendnum1 != null) {
				spendnum = Integer.parseInt(spendnum1);
			}
			 
			int spendcount = accountservice.spendcount();

			int spendpostnum = 10;
			int spendpagenum = (int) Math.ceil((double)spendcount/spendpostnum);
			int spenddisplaypost = (spendnum - 1) * spendpostnum;
			int spendpagenum_cnt = 10;
			int spendendpagenum = (int) (Math.ceil((double)spendnum/(double)spendpagenum_cnt) * spendpagenum_cnt);
			int spendstartpagenum = spendendpagenum - spendpagenum_cnt + 1;
			int spendendpagenum_tmp = (int)(Math.ceil((double)spendcount/(double)spendpagenum_cnt));
			if(spendendpagenum > spendendpagenum_tmp) {
				spendendpagenum = spendendpagenum_tmp;
			}
			boolean spendprev = spendstartpagenum == 1 ? false : true;
			boolean spendnext = spendendpagenum * spendpagenum_cnt >= spendcount ? false : true;
			map.put("spenddisplaypost", spenddisplaypost);
			map.put("spendpostnum", spendpostnum);
			 
			model.addAttribute("spendpagenum",spendpagenum);
			model.addAttribute("spendstartpagenum",spendstartpagenum);
			model.addAttribute("spendendpagenum",spendendpagenum);
			model.addAttribute("spendprev",spendprev);
			model.addAttribute("spendnext",spendnext);
			model.addAttribute("spendselect",spendnum);
			model.addAttribute("spendlist",accountservice.get_accountspend2(map));
			
			String incomenum1 = (String) map.get("incomenum");
			int incomenum = 1;
			if(incomenum1 != null) {
				incomenum = Integer.parseInt(incomenum1);
			}
			
			int incomecount = accountservice.incomecount();
	
			int incomepostnum = 10;
			int incomepagenum = (int) Math.ceil((double)incomecount/incomepostnum);
			int incomedisplaypost = (incomenum - 1) * incomepostnum;
			int incomepagenum_cnt = 10;
			int incomeendpagenum = (int)( Math.ceil((double)incomenum/(double)incomepagenum_cnt) * incomepagenum_cnt);
			int incomestartpagenum = incomeendpagenum - incomepagenum_cnt + 1;
			int incomeendpagenum_tmp = (int)(Math.ceil((double)incomecount/(double)incomepagenum_cnt));
			if(incomeendpagenum > incomeendpagenum_tmp) {
				incomeendpagenum = incomeendpagenum_tmp;
			}
			boolean incomeprev = incomestartpagenum == 1 ? false : true;
			boolean incomenext = incomeendpagenum * incomepagenum_cnt >= incomecount ? false : true;
			map.put("incomedisplaypost", incomedisplaypost);
			map.put("incomepostnum", incomepostnum);
			
			model.addAttribute("incomepagenum",incomepagenum);
			model.addAttribute("incomestartpagenum",incomestartpagenum);
			model.addAttribute("incomeendpagenum",incomeendpagenum);
			model.addAttribute("incomeprev",incomeprev);
			model.addAttribute("incomenext",incomenext);
			model.addAttribute("incomeselect",incomenum);
			model.addAttribute("incomelist",accountservice.yearlyincome2(map));
			

		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		return "account";
	}
	
	@PostMapping("/register")
	public String register(@RequestParam Map map) {
		
		try {
			accountservice.register(map);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return "redirect:/account/account";
	}
	
	@PostMapping("/stock_register")
	public String stockregister(@RequestParam Map map) {
		
		try {
			accountservice.stockregister(map);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return "redirect:/account/account";
	}
	
	

	@PostMapping("/account_spend_register")
	public String account_spend_register(@RequestParam Map map) {
		
		try {
			
			accountservice.account_spend_register(map);
			accountservice.spend_update(map);
			
			if(map.get("recipient").equals("주식")) {
				accountservice.stock_update(map);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return "redirect:/account/account";
	}
	
	@PostMapping("/stock_update2")
	public String stock_update2(@RequestParam Map map) {
		
		try {
			
			accountservice.stock_update2(map);
			accountservice.stock_update3(map);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return "redirect:/account/account";
	}
	

	@PostMapping("/income_register")
	public String income_register(@RequestParam Map map) {
		
		try {
			
			accountservice.income_register(map);
			accountservice.income_update(map);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return "redirect:/account/account";
	}
	
	
	@GetMapping("/monthly")
	public String monthly(HttpServletRequest request) {
		
		
		
		try {
		
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		return "monthly";
	}
	

}
