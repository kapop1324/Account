package com.ryu.account.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ryu.account.model.AccountSpendvo;
import com.ryu.account.model.CardSpendvo;
import com.ryu.account.model.Datavo;
import com.ryu.account.model.Incomevo;
import com.ryu.account.model.SpendtypeCountvo;
import com.ryu.account.model.Uservo;
import com.ryu.account.model.service.AccountService;

@RestController
@RequestMapping("/account_rest")
@CrossOrigin("*")
public class AccountRestController {
	
	@Autowired
	AccountService accountservice;
	
	@GetMapping("/calender")
	public ResponseEntity<List<AccountSpendvo>> accountlist(HttpServletRequest request){
		
		Uservo vo = (Uservo) request.getSession().getAttribute("signin");
		
		try {
			List<AccountSpendvo> list = accountservice.get_accountspend();
			
			return new ResponseEntity<List<AccountSpendvo>>(list,HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			
		}
		return new ResponseEntity<List<AccountSpendvo>>(HttpStatus.NO_CONTENT);
	}
	
	@GetMapping("/yearlyspend")
	public ResponseEntity<List<CardSpendvo>> yearlyspend(HttpServletRequest request){
		
		
		
		try {
			List<CardSpendvo> list = accountservice.yearlyspend();
			
			return new ResponseEntity<List<CardSpendvo>>(list,HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			
			
		}
		
		return new ResponseEntity<List<CardSpendvo>>(HttpStatus.NO_CONTENT);
	}
	
	@GetMapping("/yearly_account_spend")
	public ResponseEntity<List<AccountSpendvo>> yearlyaccountspend(HttpServletRequest request){
		
		Uservo vo = (Uservo) request.getSession().getAttribute("signin");
		
		try {
			List<AccountSpendvo> yearly_account_spend = accountservice.yearlyaccountspend();
			
			return new ResponseEntity<List<AccountSpendvo>>(yearly_account_spend,HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			
			
		}
		
		return new ResponseEntity<List<AccountSpendvo>>(HttpStatus.NO_CONTENT);
	}
	
	@GetMapping("/yearly_spend_type")
	public ResponseEntity<List<SpendtypeCountvo>> yearlyspendcount(HttpServletRequest request){
		
	
		
		try {
			List<SpendtypeCountvo> yearly_spend_type = accountservice.yearlyspendtype();
			
			return new ResponseEntity<List<SpendtypeCountvo>>(yearly_spend_type,HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			
			
		}
		
		return new ResponseEntity<List<SpendtypeCountvo>>(HttpStatus.NO_CONTENT);
	}
	
	@GetMapping("/yearly_income")
	public ResponseEntity<List<Incomevo>> yearlyincome(HttpServletRequest request){
		
		
		
		try {
			List<Incomevo> yearly_income = accountservice.yearlyincome();
		
			return new ResponseEntity<List<Incomevo>>(yearly_income,HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			
			
		}
		
		return new ResponseEntity<List<Incomevo>>(HttpStatus.NO_CONTENT);
	}
	
	@GetMapping("/yearly_income_group")
	public ResponseEntity<List<Incomevo>> yearlyincomegroup(HttpServletRequest request){
		
		try {
			List<Incomevo> yearly_income_group = accountservice.yearlyincomegroup();
		
			return new ResponseEntity<List<Incomevo>>(yearly_income_group,HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			
			
		}
		
		return new ResponseEntity<List<Incomevo>>(HttpStatus.NO_CONTENT);
	}
	
	@GetMapping("/yearly_income_month")
	public ResponseEntity<List<Incomevo>> yearlyincomemonth(HttpServletRequest request){
		
		Uservo vo = (Uservo) request.getSession().getAttribute("signin");
		
		try {
			List<Incomevo> yearly_income = accountservice.yearlyincomemonth();
		
			return new ResponseEntity<List<Incomevo>>(yearly_income,HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			
			
		}
		
		return new ResponseEntity<List<Incomevo>>(HttpStatus.NO_CONTENT);
	}
	
	@GetMapping("/yearly_delivery")
	public ResponseEntity<List<Datavo>> yearlydelivery(HttpServletRequest request){
		
		try {
			List<Datavo> yearly_delivery = accountservice.yearlydelivery();
		
			return new ResponseEntity<List<Datavo>>(yearly_delivery,HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			
			
		}
		
		return new ResponseEntity<List<Datavo>>(HttpStatus.NO_CONTENT);
	}
	
	@GetMapping("/yearly_grocery")
	public ResponseEntity<List<Datavo>> yearlygrocery(HttpServletRequest request){
		
		try {
			List<Datavo> yearly_grocery = accountservice.yearlygrocery();
		
			return new ResponseEntity<List<Datavo>>(yearly_grocery,HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			
			
		}
		
		return new ResponseEntity<List<Datavo>>(HttpStatus.NO_CONTENT);
	}
	
	@GetMapping("/yearly_rest")
	public ResponseEntity<List<Datavo>> yearlyrest(HttpServletRequest request){
		
		Uservo vo = (Uservo) request.getSession().getAttribute("signin");
		
		try {
			List<Datavo> yearly_rest = accountservice.yearlyrest();
			request.setAttribute("yearly_rest", 123);
			return new ResponseEntity<List<Datavo>>(yearly_rest,HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			
			
		}
		
		return new ResponseEntity<List<Datavo>>(HttpStatus.NO_CONTENT);
	}
	
	
	

}
